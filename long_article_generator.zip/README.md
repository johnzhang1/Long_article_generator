# AI博客生成器

这是一个使用OpenAI GPT和Unsplash API的自动化博客生成工具。它可以根据输入的大纲生成完整的博客文章，并自动插入相关的配图。

## 功能特点

- 根据输入的大纲自动生成博客文章
- 使用GPT-3.5-turbo模型确保高质量的文章内容
- 自动从Unsplash获取相关配图
- 将图片智能插入到文章的适当位置
- 输出Markdown格式的文章

## 安装步骤

1. 克隆此仓库或下载代码
2. 安装依赖包：
   ```bash
   pip install -r requirements.txt
   ```
3. 在.env文件中配置你的API密钥：
   - OPENAI_API_KEY：从OpenAI获取
   - UNSPLASH_ACCESS_KEY：从Unsplash开发者平台获取

## 使用方法

1. 运行脚本：
   ```bash
   python blog_generator.py
   ```
2. 按提示输入文章大纲，每行输入一个要点
3. 输入完成后按回车键两次
4. 等待文章生成完成
5. 生成的文章将保存为 generated_blog.md

## 注意事项

- 确保API密钥配置正确
- 确保网络连接正常
- 建议每次生成文章时使用清晰的大纲
- 生成的图片版权归Unsplash和图片作者所有，请遵守使用规范
